using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using TestCoverity_UI.Client;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");
var DefaultApi = builder.Configuration.GetValue<string>("ApiUrl:DefaultApi");
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(DefaultApi) });

await builder.Build().RunAsync();
